-- For now, this import is slightly modified from Temper-built Lua code.
local imports = require('temper-core/powersort/init-internal');
return {Powersorter = imports.Powersorter, powersort = imports.powersort};
